module.exports = function(RED) {
    function ModbusFormatNode(config) {
        RED.nodes.createNode(this, config);
        var node = this;
        
        // Retrieve the configured devices from the UI
        node.devices = config.devices || [];

        node.on('input', function(msg) {
            // Internal Function 2: Only execute if msg.topic is 'sensor_data'
            if (msg.topic !== 'sensor_data') {
                return; // Do nothing
            }

            // Ensure the expected payload structure exists
            if (!msg.payload || !msg.payload.addr || !msg.payload.original || !msg.payload.original.data) {
                return;
            }

            // Extract the last 8 characters from the incoming MAC (e.g., "00:13:a2:00:42:34:19:B3" -> "423419B3")
            let rawMac = msg.payload.addr.replace(/:/g, '').toUpperCase();
            let incomingMac = rawMac.length >= 8 ? rawMac.slice(-8) : rawMac;

            let currentAddress = 0;
            let matchedDevice = null;
            let calculatedAddress = 0;
            let matchedIndex = -1; // <-- NEW: Track the index for the Coil address

            // Iterate through user configurations to find a match and determine the starting address
            for (let i = 0; i < node.devices.length; i++) {
                let dev = node.devices[i];
                
                if (dev.mac.toUpperCase() === incomingMac) {
                    matchedDevice = dev;
                    calculatedAddress = currentAddress;
                    matchedIndex = i; // <-- NEW: Capture the index
                    break;
                }
                
                // Accumulate the registers of preceding configurations to step the starting address
                currentAddress += parseInt(dev.registers || 30, 10);
            }

            // If a match is found, build and send the Modbus payload
            // If a match is found, build and send the Modbus payloads
            if (matchedDevice) {
                let sensorDataArray = msg.payload.original.data;
                
                // Message 1: Write the sensor data to Holding Registers
                let dataMsg = RED.util.cloneMessage(msg);
                dataMsg.payload = {
                    fc: 16,
                    unitid: 1,
                    address: calculatedAddress,         
                    quantity: sensorDataArray.length,   
                    value: sensorDataArray
                };
                
                // Message 2: Write the 'New Data' flag to a Single Coil
                let coilMsg = RED.util.cloneMessage(msg);
                coilMsg.payload = {
                    fc: 5, // Modbus Function Code 5: Write Single Coil
                    unitid: 1,
                    address: matchedIndex, // Coil address matches the device list index (0, 1, 2...)
                    quantity: 1,
                    value: true // Sets the coil to 1 (ON)
                };
                
                // Send messages sequentially to the node-red-contrib-modbus Write node
                node.send(dataMsg);
                node.send(coilMsg);
            }
        });
    }

    RED.nodes.registerType("modbus-format", ModbusFormatNode);
}
