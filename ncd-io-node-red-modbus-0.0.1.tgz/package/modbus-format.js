module.exports = function(RED) {
    function ModbusFormatNode(config) {
        RED.nodes.createNode(this, config);
        var node = this;
        
        // Retrieve the configured devices from the UI
        node.devices = config.devices || [];

        node.on('input', function(msg) {
            // Internal Function 2: Only execute if msg.topic is 'sensor_data'
            if (msg.topic !== 'sensor_data') {
                return; // Do nothing
            }

            // Ensure the expected payload structure exists
            if (!msg.payload || !msg.payload.addr || !msg.payload.original || !msg.payload.original.data) {
                return;
            }

            // Extract the last 8 characters from the incoming MAC (e.g., "00:13:a2:00:42:34:19:B3" -> "423419B3")
            let rawMac = msg.payload.addr.replace(/:/g, '').toUpperCase();
            let incomingMac = rawMac.length >= 8 ? rawMac.slice(-8) : rawMac;

            let currentAddress = 0;
            let matchedDevice = null;
            let calculatedAddress = 0;

            // Iterate through user configurations to find a match and determine the starting address
            for (let i = 0; i < node.devices.length; i++) {
                let dev = node.devices[i];
                
                if (dev.mac.toUpperCase() === incomingMac) {
                    matchedDevice = dev;
                    calculatedAddress = currentAddress;
                    break;
                }
                
                // Accumulate the registers of preceding configurations to step the starting address
                currentAddress += parseInt(dev.registers || 30, 10);
            }

            // If a match is found, build and send the Modbus payload
            if (matchedDevice) {
                let sensorDataArray = msg.payload.original.data;
                
                msg.payload = {
                    fc: 16,
                    unitid: 1,
                    address: calculatedAddress,         // Decimal integer corresponding to the hex offset
                    quantity: sensorDataArray.length,   // Dynamic based on incoming payload data size
                    value: sensorDataArray
                };
                
                node.send(msg);
            }
        });
    }

    RED.nodes.registerType("modbus-format", ModbusFormatNode);
}
